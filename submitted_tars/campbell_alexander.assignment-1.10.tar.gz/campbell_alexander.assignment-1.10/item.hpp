
#pragma once

#include <vector>
using namespace std;

#include <assert.h>

#include "model.hpp"
#include "util.hpp"

// Items are generated according to the depth at which they are placed.
Item *item_generate(int depth);

